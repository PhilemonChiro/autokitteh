import{as as a,at as s}from"./index-BITPZU5I.js";const o=(o,r)=>a.lang.round(s.parse(o)[r]);export{o as c};
//# sourceMappingURL=channel-BNynlHYi.js.map
