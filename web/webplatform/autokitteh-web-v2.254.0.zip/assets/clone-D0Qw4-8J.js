import{b as r}from"./_baseUniq-D6QnG4Nr.js";function e(e){return r(e,4)}export{e as c};
//# sourceMappingURL=clone-D0Qw4-8J.js.map
