import{_ as e,d as o}from"./index-BITPZU5I.js";var t=e((e,t)=>{let n;return"sandbox"===t&&(n=o("#i"+e)),o("sandbox"===t?n.nodes()[0].contentDocument.body:"body").select(`[id="${e}"]`)},"getDiagramElement");export{t as g};
//# sourceMappingURL=chunk-BFAMUDN2-Y0G3DUrd.js.map
