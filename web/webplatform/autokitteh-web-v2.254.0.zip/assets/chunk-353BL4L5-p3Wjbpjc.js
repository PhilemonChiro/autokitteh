import{_ as c}from"./index-BITPZU5I.js";function l(c,l){var t,e,a;c.accDescr&&(null==(t=l.setAccDescription)||t.call(l,c.accDescr)),c.accTitle&&(null==(e=l.setAccTitle)||e.call(l,c.accTitle)),c.title&&(null==(a=l.setDiagramTitle)||a.call(l,c.title))}c(l,"populateCommonDb");export{l as p};
//# sourceMappingURL=chunk-353BL4L5-p3Wjbpjc.js.map
