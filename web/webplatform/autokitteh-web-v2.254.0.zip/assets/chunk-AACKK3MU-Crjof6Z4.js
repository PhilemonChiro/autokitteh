var t;import{_ as i}from"./index-BITPZU5I.js";var s=(i(t=class{constructor(t){this.init=t,this.records=this.init()}reset(){this.records=this.init()}},"ImperativeState"),t);export{s as I};
//# sourceMappingURL=chunk-AACKK3MU-Crjof6Z4.js.map
